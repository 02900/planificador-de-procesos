# planificador-de-procesos
Desarrollo en C de la estructura de datos y funciones asociadas para la implementación de un planificador de procesos
